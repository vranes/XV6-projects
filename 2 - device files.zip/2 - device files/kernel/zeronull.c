#include "types.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"


int
znread (struct inode *ip, char *buf, int n)
{
	if (ip -> minor == 1) return 0; //null
	
	int i;
	for (i=0; i<n; i++) //zero
	{
		buf[i] = '0';
	}

	return i;
}

int
znwrite(struct inode *ip, char *buf, int n)
{
	return n;
}

void
zeronullinit (void)
{
	devsw[ZERONULL].read = znread;
	devsw[ZERONULL].write = znwrite;
}