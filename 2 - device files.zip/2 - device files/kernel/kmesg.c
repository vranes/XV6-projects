#include "types.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"

#define BUFSIZE 1024
static int start = 0;
static int end = 0;
static int circle = 0;
static int buffer[BUFSIZE];


static struct file*
getfile (struct inode *ip) {
	struct proc *p = myproc();
	for (int i=0; i < NOFILE; i++) {
		if ((p->ofile[i]->ip) == ip)
			return p->ofile[i];
	}
	return 0;
}

int
kmesgread (struct inode *ip, char *buf, int n)
{
	int i=0;
	struct file* f = getfile(ip);
	if (f->off >= BUFSIZE) {
		f->off = 0;
		return 0;
	}

	for (i=0; i<n; i++)
	{
		if (f->off + i >= BUFSIZE) 		//ako offset premasi ceo bafer prekinuti da ne bi islo beskonacno
			return i-1;

		int pos = start + f->off + i;	//ako je upisano kruzno moze se citati kruzno
		if (pos >= BUFSIZE) 
			pos %= BUFSIZE;

		buf[i] = buffer[pos];
	}

	return i;
}

int
kmesgwrite(struct inode *ip, char *buf, int n)
{
	return n;
}


void
kmesginit(void)
{
	devsw[KMESG].read = kmesgread;
	devsw[KMESG].write = kmesgwrite;
}

void
kmesginsert(int c)
{
	int prev;

	end++; //end je mesto poslednjeg upisa

	if (end == BUFSIZE) 
	{
		end = 0;		//ako smo stigli do kraja bafera nastavljamo upis od pocetka
		circle = 1;		//i postavljamo kruzni flag 
	}

	prev = buffer[end];
	buffer[end] = c;

	if (c == -1 && circle == 1) //Ako smo stigli do kraja recenice i presli sa kraja bafera na pocetak treba da nadjemo 
	{							//i pocetak prve sledece recenice da bi znali odakle krecemo da citamo bafer.
		if (prev == -1) 
		{		
			start = end + 1;	//Ako je prosli put na tom mestu bio kraj recenice
		}						//na sledecem mestu pocinje nova i mozemo citati od nje.
		
		else 
		{
			int i = end + 1;
			while (buffer[i] != -1) i++;	//trazimo gde je kraj recenice koju smo pregazili
			start = i+1;					//pocetak bafera stavljamo na pocetak recenice nakon nje
		}
		
		

	}

}