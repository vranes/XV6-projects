#include "types.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "defs.h"
#include "buf.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"

static struct file*
getfile (struct inode *ip) {
	struct proc *p = myproc();
	for (int i=0; i < NOFILE; i++) {
		if ((p->ofile[i]->ip) == ip)
			return p->ofile[i];
	}
	return 0;
}



int
diskread (struct inode *ip, char *buf, int n)
{
	int i;

	struct file * f = getfile(ip);
	if (f->off >= FSSIZE*BSIZE) {
		f->off = 0;
		return 0;
	}
	int offset = f->off;
	
	int block = f->off/BSIZE + 4; 		//uprkos proveri gore mogu da premase poslednja 4
	if (block >= FSSIZE) block = (block % FSSIZE) + 4;

	struct buf *b = bread(1, block);

	for (i = 0; i < n; i++)
	{
		buf[i] = b->data[(offset)%BSIZE];
		offset++;

		if (offset >= FSSIZE*BSIZE) {
			return i;
		}
		
		if (offset % BSIZE == 0 && i != n-1) 
		{
			brelse(b);
			block = offset/BSIZE + 4;
			if (block >= FSSIZE) block = (block % FSSIZE) + 4;
			b = bread(1, block);
		}
	} 
	brelse(b);

	
	return i; 
}

int
diskwrite(struct inode *ip, char *buf, int n)
{
	struct file * f = getfile(ip);
	int offset = f->off;
	if (offset >= FSSIZE*BSIZE) offset = offset%(FSSIZE*BSIZE);
	int block = offset/BSIZE + 4;
	if (block >= FSSIZE) block = (block % FSSIZE) + 4;

	struct buf *b = bread(1, block);

	for (int i = 0; i < n; i++)
	{
		b->data[offset%BSIZE] = buf[i];
		offset++;

		if (offset >= FSSIZE*BSIZE) offset = offset%(FSSIZE*BSIZE);
		
		if (offset % BSIZE == 0 && i != n-1) 
		{
			bwrite(b);
			brelse(b);
			block = offset/BSIZE + 4;
			if (block >= FSSIZE) block = (block % FSSIZE) + 4;
			b = bread(1, block);
		}
	} 
	bwrite(b);
	brelse(b);

	return n;
}


void
diskinit (void)
{
	devsw[DISK].read = diskread;
	devsw[DISK].write = diskwrite;
}