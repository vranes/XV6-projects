#include "types.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "defs.h"

uint random;

int
randread (struct inode *ip, char *buf, int n)
{
	int r;
	int i;
	for (i=0; i<n; i++)
	{
		r = random%127;
		buf[i] = r;
		random += r%30 + ticks/9;
		random *= i/10;
		random %= 30767 / 10;
	}

	return i;
}

int
randwrite(struct inode *ip, char *buf, int n)
{
	for (int i=0; i<n; i++)
	{
		buf[i] = (buf[i] + ticks + 4)%127;
		random = (buf[i] + ticks%1000 + i);
		random %= 30767 / 10;
	}

	return n;
}


void
randominit (void)
{
	devsw[RANDOM].read = randread;
	devsw[RANDOM].write = randwrite;
}