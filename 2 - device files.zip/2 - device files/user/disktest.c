#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fcntl.h"
#include "kernel/param.h"
#include "kernel/seek.h"


int
main(void)
{
	char *buf = (char *) malloc(512);
	buf = "this is a line number 1...........\0";
	int fd, n;

	fd = open("/dev/disk", O_RDWR);

	n = write (fd, buf, strlen(buf));
	printf("disk write: %s\n",buf);

	buf = "this too is a line.\0";
	n = write (fd, buf, strlen(buf)); //pisanje sledeceg bloka
	printf("disk write: %s\n",buf);
	//for (int i=0; i<n; i++)
		//printf("%c", buf[i]);
	n = write (fd, buf, strlen(buf));
	printf("disk write: %s\n",buf);
	n = write (fd, buf, strlen(buf));
	printf("disk write: %s\n",buf);
	n = write (fd, buf, strlen(buf));
	printf("disk write: %s\n",buf);
	
	printf("premotavanje na pocetak\n");
	lseek(fd, 0, SEEK_SET);
	n = read (fd, buf, 512);
	printf("disk read: %s\n", buf);
	

	close(fd);
	exit();
}