#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
	int x = (*argv [1]) - '0'; //column
	int y = (*argv [2]) - '0'; //row
	//printf("%d %d\n", x, y);
	
	if (setcp(x, y) < 0) 
		printf("%d\n", -1);
	
	exit();
}
