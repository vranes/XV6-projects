#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fcntl.h"
#include "kernel/seek.h"
//STDIN_FILENO

int
main(int argc, char *argv[])
{
	int i;
	char *inputfile = 0;
	char *outputfile = 0;
	int fdin = 0, fdout = 1;
	int blocksize = 512, count = 0, skip = 0, seek = 0;


	for(i = 1; i < argc; i++)
	{

		char const *key = argv[i];
		char const *val = strchr(key, '=');
		val++;

		if (isop(key, "if"))
			inputfile = val;
		else if (isop(key, "of"))
			outputfile = val;
		else {
			int num = 0, weight = 1;
			num = atoi(val);
			//for (int j=0; j < strlen(val); j++)
				//num = 10*num + (val[j] - '0');

			if (isop(key, "bs"))
				blocksize = num;
			else if (isop(key, "count"))
				count = num;
			else if (isop(key, "skip"))
				skip = num;
			else if (isop(key, "seek"))
				seek = num;

		}
	}

	//printf("%d %d %d %d\n", blocksize, count, skip, seek);
	if (inputfile != 0)
		fdin = open (inputfile,  O_CREATE | O_RDONLY);
	if (outputfile != 0)
		fdout = open (outputfile, O_CREATE | O_WRONLY);
	
	//char buf [blocksize];
	char *buf = (char *) malloc(blocksize);
	
	lseek (fdin, skip*blocksize , SEEK_SET);
	lseek (fdout, seek*blocksize, SEEK_SET);
	int n = 0;
	int t;
	while ( (t = read(fdin, buf, blocksize)) > 0) //svaka iteracija ce biti sledeci blok, jer read pomera ofset
	{
		write (fdout, buf, t);
		n++;
		if (count != 0 && n >= count) break;
	}
	
	errormsg (n, blocksize);

	exit();
}

int
isop (char const *key, char const *operand)
{

	while (*operand)
		if (*key++ != *operand++) return 0;
	return (!*key || *key == '=');
}

void
itoa(int n, char s[])
{
	int i = 0;
	do {
		s[i++] = n % 10 + '0';
	} while ((n /= 10) > 0);
	s[i] = '\0';
	reverse(s);
}

void 
reverse (char s[])
{
	int i,j;
	char c;

	for (i=0, j=strlen(s)-1; i<j; i++, j--)
	{
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}

void
errormsg (int n, int blocksize)
{
	int fderr = 2;
	
	char c[] = "\n\nbroj prekopiranih blokova je: \0";
	write (fderr, c, strlen(c));
	itoa(n, c);
	write (fderr, c, strlen(c));
	char k[] = ", u bajtovima to iznosi: \0";
	write (fderr, k, strlen(k));
	itoa(n*blocksize, k);
	write (fderr, k, strlen(k)); 
}

