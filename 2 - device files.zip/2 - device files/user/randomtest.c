#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fcntl.h"


int
main(void)
{
	char *buf = (char *) malloc(512);
	//buf = "this is a test";
	int fd, n;

	fd = open("/dev/random", O_RDWR);
	if (fd < 0) {
		printf("open error");
		exit();
	}

	n = read (fd, buf, 512);
	printf("random read: \n");
	for (int i=0; i<n; i++)
		printf("%c", buf[i]);

	n = write (fd, buf, 512);
	printf("\n random write: \n");
	for (int i=0; i<n; i++)
		printf("%c", buf[i]);

	close(fd);
	exit();
}