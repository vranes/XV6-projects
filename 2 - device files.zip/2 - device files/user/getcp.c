#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
	int col;
	int row;
	int *x = &col;
	int *y = &row;
	getcp(x, y);
	printf("%d %d\n", *x, *y);
	exit();
}
