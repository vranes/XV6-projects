#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fcntl.h"


int
main(void)
{
	char *buf = (char *) malloc(512);
	int fd, n;

	fd = open("/dev/zero", O_RDWR);

	n = read (fd, buf, 512);
	printf("zero read: \n");
	for (int i=0; i<n; i++)
		printf("%c", buf[i]);

	n = write (fd, buf, 512);
	printf("\n zero write: %d\n", n);

	close(fd);


	fd = open("/dev/null", O_RDWR);

	n = read (fd, buf, 512);
	printf("\n null read: %d\n", n);

	n = write (fd, buf, 512);
	printf("\n null write: %d\n", n);

	close(fd);

	exit();
}