#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/seek.h"
#include "kernel/fcntl.h"

int
main(int argc, char *argv[])
{
	struct file *f;
	//f = filealloc();
	//int fd = fdalloc(f);
	//int fd = open("lseek.test", O_WRONLY);
	int fd = open ("lseek.test", O_CREATE | O_WRONLY);
	//f=myproc()->ofile[fd];
	//printf("%d\n", fd);

	int r = 0;
	r = lseek (fd, 70, SEEK_SET);
	printf("%d\n", r);
	write (fd, "kek", 3);
	r = lseek (fd, 70, SEEK_CUR);
	printf("%d\n", r);
	write (fd, "kek", 3);
	r = lseek (fd, 70, SEEK_END);
	printf("%d\n", r);
	r = write (fd, "kek", 3);
	printf("%d\n", r);

	exit();
}
