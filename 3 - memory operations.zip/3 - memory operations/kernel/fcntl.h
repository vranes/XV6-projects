#define O_RDONLY  0x000
#define O_WRONLY  0x001
#define O_RDWR    0x002
#define O_CREATE  0x200

#define MAP_FAILED -1
#define MAP_ANONYMOUS 1
#define PROT_READ 0x000
#define PROT_WRITE 0x002

int 			findproc(struct proc*);
struct file*	findmf(int j, void* addr, int length);
void			unmapall (struct proc*);

struct mappedfiles {
	uint start;
	uint end;
	struct file *f;
};

struct procmaps {
	struct proc *p;
	struct mappedfiles mfiles[16];
	int mfcnt;
};

struct shm {
	char *name;
	uint pages [16];
	int stat;
	int size;
	int ref;
};

/*
struct shmdir{
	struct spinlock lock;
	int use_lock;
	struct shm *head;
};*/